#!/bin/bash
/opt/jboss/bin/shutdown.sh -s 192.168.33.10 -u admin -p admin -S  >> /home/vagrant/jboss_log/jboss_shutdown.log 
